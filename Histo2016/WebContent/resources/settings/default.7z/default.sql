﻿--

 


 

-- PostgreSQL database dump

 


 

--

 


 


 

-- Dumped from database version 9.5.3

 


 

-- Dumped by pg_dump version 9.5.3

 


 


 

-- Started on 2017-07-10 18:22:51

 


 


 

SET statement_timeout = 0;

 


 

SET lock_timeout = 0;

 


 

SET client_encoding = 'UTF8';

 


 

SET standard_conforming_strings = on;

 


 

SET check_function_bodies = false;

 


 

SET client_min_messages = warning;

 


 


 


 

SET search_path = public, pg_catalog;

 


 


 

--

 


 

-- TOC entry 2628 (class 0 OID 28777)

 


 

-- Dependencies: 181

 


 

-- Data for Name: accounting; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2637 (class 0 OID 28820)

 


 

-- Dependencies: 190

 


 

-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (1, NULL, NULL, 'andreas.glatz@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (23, NULL, NULL, 'bastian.grundel@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4057', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (2, NULL, NULL, 'sylvia.zeitler@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40580', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (3, NULL, NULL, 'brigitte.joos@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40580', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (22, NULL, NULL, 'nikolai.gross@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4011', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (21, NULL, NULL, 'alexandra.anton@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4052', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (20, NULL, NULL, 'marie-christine.bruender@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4091', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (31, NULL, NULL, 'clemens.lange@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4042', '+49 761 270 40511', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (4, NULL, NULL, 'thomas.reinhard@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40060', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (6, NULL, NULL, 'claudia.auw-haedrich@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4058', '+49 761 270 41950', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (7, NULL, NULL, 'hansjuergen.agostini@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4046', '+49 761 270 40460', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (8, NULL, NULL, 'wolf.lagreze@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40100', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (9, NULL, NULL, 'philip.maier@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4116', '+49 761 270 40990', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (10, NULL, NULL, 'laura.gasser@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4093', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (30, NULL, NULL, 'thomas.wecker@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4059', '+49 761 270 40520', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (29, NULL, NULL, 'Christoph.Reichel@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4077', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (28, NULL, NULL, 'thomas.ness@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4053', '+49 761 270 40518', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (27, NULL, NULL, 'Lutz.Joachimsen@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4067', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (26, NULL, NULL, 'sabine.reichl@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4047', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (25, NULL, NULL, 'charlotte.evers@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4014', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (24, NULL, NULL, 'andreas.stahl@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4026', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (19, NULL, NULL, 'milena.stech@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4043', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (18, NULL, NULL, 'franziska.ludwig@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4064', NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (11, NULL, NULL, 'philipp.eberwein@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4066', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (13, NULL, NULL, 'jan.luebke@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4092', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (12, NULL, NULL, 'stefan.lang@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4082', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (14, NULL, NULL, 'thabo.lapp@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (15, NULL, NULL, 'lisa.zimmermann@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4065', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (16, NULL, NULL, 'vanessa.frommherz@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4099', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (17, NULL, NULL, 'Tim.Bleul@uniklinik-freiburg.de', NULL, NULL, NULL, '12-4006', '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (40, NULL, NULL, 'susanne.issleib@uniklinik-freiburg.de', '', NULL, NULL, NULL, '+49 761 270 40010', '', '', '');

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (33, NULL, NULL, 'kristina.schoelles@uniklinik-freiburg.de', '', NULL, NULL, NULL, '+49 761 270 40010', '', '', '');

 


 

INSERT INTO contact (id, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (5, NULL, NULL, 'hans.mittelviefhaus@uniklinik-freiburg.de', '', NULL, NULL, '12-4051', '+49 761 270 40510', '', '', '');

 


 


 


 

--

 


 

-- TOC entry 2671 (class 0 OID 29041)

 


 

-- Dependencies: 224

 


 

-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (1, false, NULL, NULL, 'Andreas', 1, NULL, 'Glatz', NULL, 'Dr.', 1, 1);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (21, false, NULL, NULL, 'Alexandra', 1, NULL, 'Anton', NULL, 'Dr.', 1, 21);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (22, false, NULL, NULL, 'Nikolai', 0, NULL, 'Gross', NULL, 'Dr.', 1, 22);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (11, false, NULL, NULL, 'Philipp', 0, NULL, 'Eberwein', NULL, 'PD Dr.', 1, 11);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (12, false, NULL, NULL, 'Stefan', 0, NULL, 'Lang', NULL, 'Dr.', 1, 12);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (13, false, NULL, NULL, 'Jan', 0, NULL, 'Lübke', NULL, 'Dr.', 1, 13);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (14, false, NULL, NULL, 'Benjamin Thabo', 0, NULL, 'Lapp', NULL, 'Dr.', 1, 14);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (15, false, NULL, NULL, 'Lisa', 1, NULL, 'Zimmermann', NULL, 'Dr.', 1, 15);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (16, false, NULL, NULL, 'Vanessa', 1, NULL, 'Frommherz', NULL, 'Dr.', 1, 16);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (17, false, NULL, NULL, 'Tim', 0, NULL, 'Bleul', NULL, 'Dr.', 1, 17);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (18, false, NULL, NULL, 'Franziska', 1, NULL, 'Ludwig', NULL, 'Dr.', 1, 18);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (19, false, NULL, NULL, 'Milena', 1, NULL, 'Stech', NULL, 'Dr.', 1, 19);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (2, false, NULL, NULL, 'Sylvia', 1, NULL, 'Zeitler', NULL, NULL, 1, 2);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (3, false, NULL, NULL, 'Brigitte', 1, NULL, 'Joos', NULL, NULL, 1, 3);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (4, false, NULL, NULL, 'Thomas', 0, NULL, 'Reinhard', NULL, 'Prof.Dr.', 1, 4);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (6, false, NULL, NULL, 'Claudia', 1, NULL, 'Auw-Hädrich', NULL, 'Apl.Prof.Dr.', 1, 6);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (7, false, NULL, NULL, 'Hansjürgen', 0, NULL, 'Agostini', NULL, 'Apl.Prof.Dr.', 1, 7);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (8, false, NULL, NULL, 'Wolf Alexander', 0, NULL, 'Lagrèze', NULL, 'Prof. Dr.', 1, 8);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (10, false, NULL, NULL, 'Laura', 1, NULL, 'Laura', NULL, 'PD Dr.', 1, 10);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (9, false, NULL, NULL, 'Philip', 0, NULL, 'Maier', NULL, 'PD Dr.', 1, 9);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (28, false, NULL, NULL, 'Thomas', 0, NULL, 'Neß', NULL, 'PD Dr.', 1, 28);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (27, false, NULL, NULL, 'Lutz', 0, NULL, 'Joachimsen', NULL, 'Dr.', 1, 27);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (26, false, NULL, NULL, 'Sabine', 1, NULL, 'Reichl', NULL, 'Dr.', 1, 26);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (25, false, NULL, NULL, 'Charlotte', 1, NULL, 'Evers', NULL, 'Dr.', 1, 25);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (24, false, NULL, NULL, 'Andreas', 0, NULL, 'Stahl', NULL, 'Apl.Prof.Dr.', 1, 24);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (23, false, NULL, NULL, 'Bastian', 0, NULL, 'Grundel', NULL, 'Dr.', 1, 23);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (31, false, NULL, NULL, 'Clemens', 0, NULL, 'Lange', NULL, 'PD Dr. Dr.', 1, 31);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (30, false, NULL, NULL, 'Thomas', 0, NULL, 'Wecker', NULL, 'Dr.', 1, 30);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (29, false, NULL, NULL, 'Christoph', 0, NULL, 'Reichel', NULL, 'Dr.', 1, 29);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (20, false, NULL, NULL, 'Marie-Christine', 1, NULL, 'Bründer', NULL, 'Dr.', 1, 20);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (32, false, NULL, NULL, 'Kristina', 1, NULL, 'Schölles', NULL, 'Dr.', 0, 33);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (38, false, NULL, NULL, 'Susanne', 1, NULL, 'Ißleib', NULL, '', 0, 40);

 


 

INSERT INTO person (id, archived, birthname, birthday, firstname, gender, language, lastname, note, title, version, contact_id) VALUES (5, false, NULL, NULL, 'Hans', 0, NULL, 'Mittelviefhaus', NULL, 'Prof.Dr.', 2, 5);

 


 


 


 

--

 


 

-- TOC entry 2675 (class 0 OID 29065)

 


 

-- Dependencies: 228

 


 

-- Data for Name: physician; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (1, false, true, 'Arzt', '1-30038224-0', 'glatza', 1, 1);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (2, false, true, 'Techn. Assistentin Med.', '1-30014504-0', 'zeitler', 1, 2);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (3, false, true, 'Techn. Assistentin Med.', '1-27901941-0', 'joosb', 1, 3);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (4, false, true, 'Ärztlicher Direktor', '1-30006999-0', 'treinhar', 1, 4);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (5, false, true, 'Oberarzt', '1-26604181-0', 'mvh', 1, 5);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (6, false, true, 'Oberärztin', '1-27304491-0', 'auw', 1, 6);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (7, false, true, 'Leitender Oberarzt', '1-28108201-0', 'agostini', 1, 7);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (8, false, true, 'Sektionsleiter', '1-27472961-0', 'lagreze', 1, 8);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (9, false, true, 'Oberarzt', '1-30003406-0', 'maierphi', 1, 9);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (10, false, true, 'Funktionsoberärztin', '1-30012620-0', 'gasser', 1, 10);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (11, false, true, 'Oberarzt', '1-30009182-0', 'eberwein', 1, 11);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (12, false, true, 'Funktionsoberarzt', '1-30022472-0', 'langst', 1, 12);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (13, false, true, 'Arzt', '1-30028879-0', 'luebkej', 1, 13);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (14, false, true, 'Funktionsoberarzt', '1-30018756-0', 'lapp', 1, 14);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (15, false, true, 'Ärztin', '1-30011238-0', 'zimmeli', 1, 15);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (16, false, true, 'Ärztin', '1-30019294-0', 'frommhev', 1, 16);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (17, false, true, 'Arzt', '1-30037716-0', 'bleult', 1, 17);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (18, false, true, 'Ärztin', '1-30023875-0', 'ludwigfr', 1, 18);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (19, false, true, 'Ärztin', '1-30028878-0', 'stech', 1, 19);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (20, false, true, 'Ärztin', '1-30017062-0', 'bruender', 1, 20);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (21, false, true, 'Fachärztin', '1-30015342-0', 'anton', 1, 21);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (22, false, true, 'Funktionsoberarzt', '1-30012696-0', 'grossnik', 1, 22);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (23, false, true, 'Facharzt', '1-30017059-0', 'grundel', 1, 23);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (24, false, true, 'Oberarzt', '1-30011235-0', 'astahl', 1, 24);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (25, false, true, 'Ärztin', '1-30025750-0', 'eversc', 1, 25);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (26, false, true, 'Ärztin', '1-30028609-0', 'reichl', 1, 26);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (27, false, true, 'Funktionsoberarzt', '1-30036972-0', 'joachims', 1, 27);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (28, false, true, 'Oberarzt', '1-27362821-0', 'ness', 1, 28);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (29, false, true, 'Arzt', '1-30022069-0', 'reichelc', 1, 29);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (30, false, true, 'Funktionsoberarzt', '1-30023645-0', 'wecker', 1, 30);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (31, false, true, 'Oberarzt', '1-30011659-0', 'clelange', 1, 31);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (32, false, true, 'Ärztin', '1-30038747-0', 'schoelle', 0, 32);

 


 

INSERT INTO physician (id, archived, clinicemployee, clinicrole, employeenumber, uid, version, person_id) VALUES (38, false, true, 'Ärztin', '1-30024710-0', 'issleibs', 0, 38);

 


 


 


 

--

 


 

-- TOC entry 2654 (class 0 OID 28929)

 


 

-- Dependencies: 207

 


 

-- Data for Name: histouser; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO histouser (id, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, version, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, alternatepatientaddmode, physician_id) VALUES (2, true, true, 8, 0, NULL, NULL, 'MTA', 'joosb', 1, false, true, 0, true, 0, false, 2);

 


 

INSERT INTO histouser (id, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, version, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, alternatepatientaddmode, physician_id) VALUES (3, true, true, 8, 0, NULL, NULL, 'MTA', 'zeitler', 1, false, true, 0, true, 0, false, 3);

 


 

INSERT INTO histouser (id, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, version, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, alternatepatientaddmode, physician_id) VALUES (4, true, true, 9, 0, NULL, NULL, 'PHYSICIAN', 'zimmeli', 1, false, true, 0, true, 1, false, 15);

 


 

INSERT INTO histouser (id, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, version, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, alternatepatientaddmode, physician_id) VALUES (5, true, true, 9, 0, NULL, NULL, 'MODERATOR', 'auw', 1, false, true, 0, true, 1, false, 6);

 


 

INSERT INTO histouser (id, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, version, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, alternatepatientaddmode, physician_id) VALUES (1, true, true, 9, 1499702997244, NULL, '

 


 

', 'ADMIN', 'glatza', 3, false, true, 0, true, 1, false, 1);

 


 


 


 

--

 


 

-- TOC entry 2665 (class 0 OID 29001)

 


 

-- Dependencies: 218

 


 

-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2658 (class 0 OID 28961)

 


 

-- Dependencies: 211

 


 

-- Data for Name: log; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (1, 'Benutzerdaten geupdated', 1499702505204, NULL, NULL);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (52, 'Neue Organisation (Organization [id=0, version=0, name=Klinik für Augenheilkunde, contact=org.histo.model.Contact@3a88cc0b, note=null, persons=null, intern=false]) erstellt.', 1499702997357, NULL, NULL);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (53, 'Benutzerdaten aktualisiert. (HistoUser [id=1, username=glatza])', 1499702997457, NULL, NULL);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (54, NULL, 1499703037103, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (55, 'Neue Organisation (Organization [id=0, version=0, name=Klinik für Augenheilkunde Klinische Forschung, contact=org.histo.model.Contact@6d885fe3, note=null, persons=null, intern=false]) erstellt.', 1499703511403, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (56, '???Neue Person hinzugefügt Ißleib Susanne.???', 1499703511515, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (57, '???Personendaten geupdatet Ißleib Susanne. ???', 1499703530431, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (58, 'Personendaten oder Rolle geändert Ißleib Susanne. ', 1499703539344, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (59, 'Personendaten oder Rolle geändert Dr. Schölles Kristina. ', 1499703542752, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (60, '???Personendaten geupdatet Prof.Dr. Reinhard Thomas. ???', 1499703619384, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (61, NULL, 1499703629482, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (62, 'Person (Prof.Dr. Mittelviefhaus Hans) zur Organisation (Klinik für Augenheilkunde) hinzugefügt. ', 1499703631644, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (63, 'Personendaten oder Rolle geändert Prof.Dr. Mittelviefhaus Hans. ', 1499703632394, NULL, 1);

 


 

INSERT INTO log (id, logstring, "timestamp", patient_id, useracc_id) VALUES (64, '???Personendaten geupdatet Apl.Prof.Dr. Auw-Hädrich Claudia. ???', 1499703641984, NULL, 1);

 


 


 


 

--

 


 

-- TOC entry 2629 (class 0 OID 28782)

 


 

-- Dependencies: 182

 


 

-- Data for Name: accounting_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2722 (class 0 OID 0)

 


 

-- Dependencies: 244

 


 

-- Name: accounting_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('accounting_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2686 (class 0 OID 29139)

 


 

-- Dependencies: 239

 


 

-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2630 (class 0 OID 28787)

 


 

-- Dependencies: 183

 


 

-- Data for Name: associatedcontact; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2723 (class 0 OID 0)

 


 

-- Dependencies: 245

 


 

-- Name: associatedcontact_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('associatedcontact_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2631 (class 0 OID 28792)

 


 

-- Dependencies: 184

 


 

-- Data for Name: biobank; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2632 (class 0 OID 28797)

 


 

-- Dependencies: 185

 


 

-- Data for Name: biobank_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2669 (class 0 OID 29025)

 


 

-- Dependencies: 222

 


 

-- Data for Name: pdfcontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2633 (class 0 OID 28802)

 


 

-- Dependencies: 186

 


 

-- Data for Name: biobank_pdfcontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2634 (class 0 OID 28805)

 


 

-- Dependencies: 187

 


 

-- Data for Name: biobank_pdfcontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2724 (class 0 OID 0)

 


 

-- Dependencies: 246

 


 

-- Name: biobank_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('biobank_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2659 (class 0 OID 28966)

 


 

-- Dependencies: 212

 


 

-- Data for Name: materialpreset; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (1, '', 1, 'Hautpräparat');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (2, '', 2, 'Hornhaut');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (3, '', 3, 'Descemet');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (4, '', 4, 'Salzmannknoten');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (5, '', 5, 'Biopsie');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (6, '', 6, 'Bindehaut');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (7, '', 7, 'Lidkante');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (8, '', 8, 'Resektat');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (9, '', 9, 'Nachresektat');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (10, '', 10, 'Bulbus');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (11, '', 11, 'Eviszeratio');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (12, '', 12, 'Exenteration');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (13, '', 13, 'Zyste');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (14, '', 14, 'Arterie');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (15, '', 15, 'Bindehautabstrich');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (16, '', 16, 'Iris');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (17, '', 17, 'Linse');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (18, '', 18, 'Linsenkapsel');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (19, '', 19, 'Ziliarkörper');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (20, '', 20, 'Aderhaut');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (21, '', 21, 'Netzhaut');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (22, '', 22, 'Glaskörper');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (23, '', 23, 'Glaskörperaspirat');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (24, '', 24, 'Sklera');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (25, '', 25, 'Vorderkammer');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (26, '', 26, 'N. Optikus');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (27, '', 27, 'Keilexcisat');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (28, '', 28, 'Tränensack');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (29, '', 29, 'Augenmuskel');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (30, '', 30, 'Irisgewebe');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (31, '', 31, 'Orbitagewebe');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (32, '', 32, 'kein Material');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (33, '', 33, 'Paraffinblock');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (34, '', 34, 'Schnitte');

 


 

INSERT INTO materialpreset (id, commentary, indexinlist, name) VALUES (35, '', 0, 'Keine Ausgewählt');

 


 


 


 

--

 


 

-- TOC entry 2679 (class 0 OID 29089)

 


 

-- Dependencies: 232

 


 

-- Data for Name: sample; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2635 (class 0 OID 28810)

 


 

-- Dependencies: 188

 


 

-- Data for Name: block; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2636 (class 0 OID 28815)

 


 

-- Dependencies: 189

 


 

-- Data for Name: block_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2725 (class 0 OID 0)

 


 

-- Dependencies: 247

 


 

-- Name: block_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('block_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2638 (class 0 OID 28828)

 


 

-- Dependencies: 191

 


 

-- Data for Name: contact_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (32, 52, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (33, 54, 0, NULL, NULL, 'kristina.schoelles@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (39, 55, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (40, 56, 0, NULL, NULL, 'susanne.issleib@uniklinik-freiburg.de', NULL, NULL, NULL, NULL, '+49 761 270 40010', NULL, NULL, NULL);

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (40, 58, 1, NULL, NULL, 'susanne.issleib@uniklinik-freiburg.de', '', NULL, NULL, NULL, '+49 761 270 40010', '', '', '');

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (33, 59, 1, NULL, NULL, 'kristina.schoelles@uniklinik-freiburg.de', '', NULL, NULL, NULL, '+49 761 270 40010', '', '', '');

 


 

INSERT INTO contact_aud (id, rev, revtype, building, country, email, fax, homepage, mobile, pager, phone, postcode, street, town) VALUES (5, 61, 1, NULL, NULL, 'hans.mittelviefhaus@uniklinik-freiburg.de', '', NULL, NULL, '12-4051', '+49 761 270 40510', '', '', '');

 


 


 


 

--

 


 

-- TOC entry 2726 (class 0 OID 0)

 


 

-- Dependencies: 248

 


 

-- Name: contact_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('contact_sequence', 81, true);

 


 


 


 

--

 


 

-- TOC entry 2639 (class 0 OID 28836)

 


 

-- Dependencies: 192

 


 

-- Data for Name: council; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2640 (class 0 OID 28844)

 


 

-- Dependencies: 193

 


 

-- Data for Name: council_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2641 (class 0 OID 28852)

 


 

-- Dependencies: 194

 


 

-- Data for Name: council_pdfcontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2642 (class 0 OID 28855)

 


 

-- Dependencies: 195

 


 

-- Data for Name: council_pdfcontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2727 (class 0 OID 0)

 


 

-- Dependencies: 249

 


 

-- Name: council_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('council_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2681 (class 0 OID 29105)

 


 

-- Dependencies: 234

 


 

-- Data for Name: signature; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2645 (class 0 OID 28876)

 


 

-- Dependencies: 198

 


 

-- Data for Name: diagnosiscontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2647 (class 0 OID 28886)

 


 

-- Dependencies: 200

 


 

-- Data for Name: diagnosispreset; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (1, '', '', 'folgt', '', '', 0, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (26, 'Nävus', '', 'Nävuszellnävus mit junktionaler Aktivität', '', 'D23.1', 25, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (31, '', '', 'Endothelversagen', '', 'H16.8', 30, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (40, '', '', 'perforiertes Hornhautulkus', '', 'H16.0', 39, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (15, 'Chalazion', '', 'Chalazion', '', 'H00.1', 14, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (16, 'Pterygium', '', 'Pterygium', '', 'H11.0', 15, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (17, 'Keratokonus', '', 'Keratokonus', '', 'H18.6', 16, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (2, 'Basaliom', '', 'solides Basaliom, im Gesunden entfernt', '', 'C44.1', 1, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (3, 'Basaliom', '', 'solides Basaliom, knapp im Gesunden entfernt', '', 'C44.1', 2, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (4, 'Basaliom', '', 'solides Basaliom, nicht im Gesunden entfernt', '', 'C44.1', 3, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (42, 'Arteriitis temporalis', '', 'Arteriitis temporalis', '', 'M31.6', 41, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (35, '', '', 'Transplantatversagen', '', 'H17.8', 34, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (36, '', '', 'vereinbar mit Herpeskeratitis', '', 'H19.1', 35, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (5, 'Basaliom ', '', 'solides Basaliom mit fibrosierendem Charakter, im Gesunden entfernt', '', 'C44.1', 4, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (6, 'Basaliom ', '', 'solides Basaliom mit fibrosierendem Charakter, knapp im Gesunden entfernt', '', 'C44.1', 5, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (7, 'Basaliom ', '', 'solides Basaliom mit fibrosierendem Charakter, nicht im Gesunden entfernt', '', 'C44.1', 6, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (12, 'Fuchssche Endotheldystrophie', '', 'Descemetmembran bei Fuchsscher Endotheldystrophie', '', '', 11, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (13, '', '', 'tumorfreies Nachresektat', '', '', 12, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (14, 'Plattenepithelkarzinom', '', 'Plattenepithelkarzinom', '', '', 13, 'true');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (18, '', '', 'Kunststoffeinbettung', '', '', 17, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (19, '', '', 'Scrophulosa', '', '', 18, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (20, '', '', 'pyogenes Granulom', '', '', 19, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (10, 'Basaliom', '', 'fibrosierendes Basaliom, nicht im Gesunden entfernt', '', 'C44.1', 9, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (9, 'Basaliom', '', 'fibrosierendes Basaliom, knapp im Gesunden entfernt', '', 'C44.1', 8, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (8, 'Basaliom', '', 'fibrosierendes Basaliom, im Gesunden entfernt', '', 'C44.1', 7, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (11, 'Papillom', '', 'Plattenepithelpapillom', '', 'D23.1', 10, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (21, 'Papillom', '', 'Basalzellpapillom', '', 'D23.1', 20, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (22, '', '', 'Pinguecula', '', '', 21, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (45, '', '', 'Bindehautzyste', '', 'D23.1', 44, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (23, '', '', 'Lidfehlstellung', '', 'H02.1', 22, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (43, 'Dermoidzyste', '', 'Dermoidzyste', '', 'D23.1', 42, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (25, 'Nävus', '', 'dermaler Nävuszellnävus', '', 'D23.1', 24, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (24, 'Nävus', '', 'Nävuszellnävus ', '', 'D23.1', 23, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (30, 'Nävus', '', 'Bindehautnävus mit junktionaler Aktivität', '', 'D23.1', 29, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (32, '', '', 'Limbusinsuffizienz', '', '', 31, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (29, 'Nävus', '', 'Bindehautnävus', '', 'D23.1', 28, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (28, 'Nävus', '', 'subepithelialer Nävus', '', 'D23.1', 27, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (33, '', '', 'Endotheldekompensation', '', '', 32, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (27, 'Nävus', '', 'dermaler Nävus mit junktionaler Aktivität', '', 'D23.1', 26, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (34, '', '', 'Fuchs''sche Endotheldystrophie', '', '', 33, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (37, '', '', 'Zustand nach Keratoplastik', '', '', 36, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (38, 'Salzmannknoten', '', 'Salzmannknoten', '', '', 37, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (39, 'Seborrhoische Keratose', '', 'Seborrhoische Keratose', '', '', 38, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (41, 'Katarakt', '', 'Katarakt', '', '', 40, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (44, 'Papillom', '', 'Bindehautpapillom', '', '', 43, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (46, '', '', 'Moll''sche Zyste', '', '', 45, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (48, '', '', 'Molluscum contagiosum', '', '', 47, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (51, '', '', 'kein Material im Labor eingetroffen', '', '', 50, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (52, '', '', 'kein Material im Gefäß', '', '', 51, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (53, '', '', 'winziges Präparat, verloren während des Einbettungsprozesses', '', '', 52, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (54, 'Melanom', '', 'Melanom der Aderhaut', '', '', 53, 'true');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (50, 'Melanom', '', 'Bindehautmelanom', '', '', 49, 'true');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (49, '', '', 'Xanthelasma', '', 'D23.1', 48, 'false');

 


 

INSERT INTO diagnosispreset (id, category, commentary, diagnosis, extendeddiagnosistext, icd10, indexinlist, malign) VALUES (47, '', '', 'Epidermiszyste', '', 'D23.1', 46, 'false');

 


 


 


 

--

 


 

-- TOC entry 2649 (class 0 OID 28897)

 


 

-- Dependencies: 202

 


 

-- Data for Name: diagnosisrevision; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2643 (class 0 OID 28860)

 


 

-- Dependencies: 196

 


 

-- Data for Name: diagnosis; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2644 (class 0 OID 28868)

 


 

-- Dependencies: 197

 


 

-- Data for Name: diagnosis_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2728 (class 0 OID 0)

 


 

-- Dependencies: 250

 


 

-- Name: diagnosis_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('diagnosis_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2646 (class 0 OID 28881)

 


 

-- Dependencies: 199

 


 

-- Data for Name: diagnosiscontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2729 (class 0 OID 0)

 


 

-- Dependencies: 251

 


 

-- Name: diagnosiscontainer_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('diagnosiscontainer_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2648 (class 0 OID 28894)

 


 

-- Dependencies: 201

 


 

-- Data for Name: diagnosispreset_diagnosisreportasletter; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2730 (class 0 OID 0)

 


 

-- Dependencies: 252

 


 

-- Name: diagnosispreset_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('diagnosispreset_sequence', 54, true);

 


 


 


 

--

 


 

-- TOC entry 2650 (class 0 OID 28905)

 


 

-- Dependencies: 203

 


 

-- Data for Name: diagnosisrevision_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2731 (class 0 OID 0)

 


 

-- Dependencies: 253

 


 

-- Name: diagnosisrevision_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('diagnosisrevision_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2651 (class 0 OID 28913)

 


 

-- Dependencies: 204

 


 

-- Data for Name: favouritelist; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (1, true, false, false, 'Färbeliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (2, true, false, false, 'Diagnosislist', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (3, true, false, false, 'Benachrichtigungsliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (4, true, false, false, 'Nachfärbeliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (5, true, false, false, 'Rediagnoseliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (6, true, false, false, 'Verbleibe in Färbeliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (7, true, false, false, 'Verbleibe in Diangoseliste', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (8, true, false, false, 'Verbleibe in Benachrichtigungslite', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (9, true, false, false, 'Konsil-Ausleihe (MTA)', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (10, true, false, false, 'Konsil-Ausleihe (Sekretariat)', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (11, true, false, false, 'Konsil steht aus', NULL);

 


 

INSERT INTO favouritelist (id, defaultlist, editable, global, name, owner_id) VALUES (12, true, false, false, 'Konsil erledigt', NULL);

 


 


 


 

--

 


 

-- TOC entry 2732 (class 0 OID 0)

 


 

-- Dependencies: 254

 


 

-- Name: favouritelist_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('favouritelist_sequence', 12, true);

 


 


 


 

--

 


 

-- TOC entry 2652 (class 0 OID 28921)

 


 

-- Dependencies: 205

 


 

-- Data for Name: favouritelistitem; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2733 (class 0 OID 0)

 


 

-- Dependencies: 255

 


 

-- Name: favouritelistitem_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('favouritelistitem_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2685 (class 0 OID 29131)

 


 

-- Dependencies: 238

 


 

-- Data for Name: stainingprototype; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (1, false, '', 0, 'Trichrom-Masson', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (2, false, '', 1, 'Trichrom-Goldner', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (3, false, '', 2, 'AMP', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (4, false, '', 3, 'Kongorot', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (5, false, '', 4, 'Giemsa', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (6, false, '', 5, 'GMS', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (7, false, '', 6, 'Gram', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (8, false, '', 7, 'FE', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (9, false, '', 8, 'PAS', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (10, false, '', 9, 'van Gieson', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (11, false, '', 10, 'HE', 'NORMAL');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (12, false, '', 11, 'Melan A', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (13, false, '', 12, 'HMB 45', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (14, false, '', 13, 'Mib 1', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (15, false, '', 14, 'Vimentin', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (16, false, '', 15, 'Cytokeratin AE1-AE3', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (17, false, '', 16, 'GFAP', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (18, false, '', 17, 'S100', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (19, false, '', 18, 'NSE', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (20, false, '', 19, 'CD68', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (21, false, '', 20, 'CD34', 'IMMUN');

 


 

INSERT INTO stainingprototype (id, archived, commentary, indexinlist, name, type) VALUES (22, false, '', 21, 'Faktor VIII', 'IMMUN');

 


 


 


 

--

 


 

-- TOC entry 2683 (class 0 OID 29115)

 


 

-- Dependencies: 236

 


 

-- Data for Name: slide; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2653 (class 0 OID 28926)

 


 

-- Dependencies: 206

 


 

-- Data for Name: favouritelistitem_slide; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2734 (class 0 OID 0)

 


 

-- Dependencies: 271

 


 

-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2655 (class 0 OID 28937)

 


 

-- Dependencies: 208

 


 

-- Data for Name: histouser_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO histouser_aud (id, rev, revtype, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, physician_id) VALUES (1, 1, 1, true, true, 9, 1499702505093, NULL, '

 


 

', 'ADMIN', 'glatza', false, true, 0, true, 1, 1);

 


 

INSERT INTO histouser_aud (id, rev, revtype, autoselectedpreferedlabelprinter, autoselectedpreferedprinter, defaultview, lastlogin, preferedlabelpritner, preferedprinter, role, username, worklistautoupdate, worklisthidenoneactivetasks, worklistsortorder, worklistsortorderasc, worklisttoload, physician_id) VALUES (1, 53, 1, true, true, 9, 1499702997244, NULL, '

 


 

', 'ADMIN', 'glatza', false, true, 0, true, 1, 1);

 


 


 


 

--

 


 

-- TOC entry 2656 (class 0 OID 28945)

 


 

-- Dependencies: 209

 


 

-- Data for Name: listitem; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (1, false, 0, 'CASE_HISTORY', 'V. a. Chalazion');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (3, false, 2, 'CASE_HISTORY', 'V.a. pyogenes Granulom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (2, false, 1, 'CASE_HISTORY', 'V.a. Chalazion/pyogenes Granulom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (5, false, 4, 'CASE_HISTORY', 'Nachresektion bei Basaliom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (4, false, 3, 'CASE_HISTORY', 'V. a. Basaliom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (7, false, 6, 'CASE_HISTORY', 'V. a. Papillom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (6, false, 5, 'CASE_HISTORY', 'Nachresektion z. Vergrößerung Sicherheitsabstand');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (9, false, 8, 'CASE_HISTORY', 'V.a. Verruca vulg.');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (8, false, 7, 'CASE_HISTORY', 'V.a. Pterygium');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (10, false, 9, 'CASE_HISTORY', 'Lidrandzyste');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (12, false, 11, 'CASE_HISTORY', 'Xanthelasma');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (11, false, 10, 'CASE_HISTORY', 'V. a. CIN');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (13, false, 12, 'CASE_HISTORY', 'V. a. aktinische Keratose');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (16, false, 15, 'CASE_HISTORY', 'V.a. Nävus');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (15, false, 14, 'CASE_HISTORY', 'V. a. Dermoidzyste');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (14, false, 13, 'CASE_HISTORY', 'V. a. Epidermiszyste');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (18, false, 17, 'CASE_HISTORY', 'V. a. Lymphom');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (17, false, 16, 'CASE_HISTORY', 'V. a. Bindehautnävus');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (19, false, 18, 'CASE_HISTORY', 'Keil bei Blaskovic');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (21, false, 20, 'CASE_HISTORY', 'V. a. Arteriitis temporalis');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (23, false, 22, 'CASE_HISTORY', 'V. a. Salzmannknoten');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (22, false, 21, 'CASE_HISTORY', 'Keratokonus');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (20, false, 19, 'CASE_HISTORY', 'V. a. Mollzyste');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (24, false, 23, 'CASE_HISTORY', 'DMEK');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (26, false, 25, 'CASE_HISTORY', 'Bullosa');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (25, false, 24, 'CASE_HISTORY', 'Descemet bei Fuchs');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (27, false, 26, 'CASE_HISTORY', 'Endothelversagen');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (29, false, 28, 'CASE_HISTORY', 'Limbusinsuffizienz');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (28, false, 27, 'CASE_HISTORY', 'Fuchs''sche Endotheldystrophie');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (30, false, 29, 'CASE_HISTORY', 'Z. n. Herpes');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (31, false, 30, 'CASE_HISTORY', 'Herpesnarbe');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (33, false, 32, 'CASE_HISTORY', 'Re-Keratokonus');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (32, false, 31, 'CASE_HISTORY', 'Transplantatversagen');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (34, false, 33, 'CASE_HISTORY', 'bullöse Keratopathie');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (35, false, 34, 'CASE_HISTORY', 'Pinguecula');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (36, false, 0, 'WARDS', 'ambulant');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (38, false, 2, 'WARDS', 'ambulant-privat');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (37, false, 1, 'WARDS', 'stationär');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (39, false, 3, 'WARDS', 'stationär-privat');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (41, false, 5, 'WARDS', 'auswärtig');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (40, false, 4, 'WARDS', 'IMS-privat');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (42, false, 6, 'WARDS', 'auswärtig-privat');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (43, false, 0, 'COUNCIL_ATTACHMENT', 'je ein HE und PAS-Schnitt');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (44, false, 1, 'COUNCIL_ATTACHMENT', '20 Leerschnitte');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (45, false, 2, 'COUNCIL_ATTACHMENT', '10 Leerschnitte');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (46, false, 3, 'COUNCIL_ATTACHMENT', 'Leerschnitte');

 


 

INSERT INTO listitem (id, archived, indexinlist, listtype, value) VALUES (47, false, 4, 'COUNCIL_ATTACHMENT', 'Paraffinblock');

 


 


 


 

--

 


 

-- TOC entry 2657 (class 0 OID 28953)

 


 

-- Dependencies: 210

 


 

-- Data for Name: listitem_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2735 (class 0 OID 0)

 


 

-- Dependencies: 256

 


 

-- Name: listitem_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('listitem_sequence', 47, true);

 


 


 


 

--

 


 

-- TOC entry 2736 (class 0 OID 0)

 


 

-- Dependencies: 257

 


 

-- Name: log_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('log_sequence', 101, true);

 


 


 


 

--

 


 

-- TOC entry 2737 (class 0 OID 0)

 


 

-- Dependencies: 258

 


 

-- Name: materialpreset_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('materialpreset_sequence', 35, true);

 


 


 


 

--

 


 

-- TOC entry 2660 (class 0 OID 28974)

 


 

-- Dependencies: 213

 


 

-- Data for Name: materialpreset_stainingprototype; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (1, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (1, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (2, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (2, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (3, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (3, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (4, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (4, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (5, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (5, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (6, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (6, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (7, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (7, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (8, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (8, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (9, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (9, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (10, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (10, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (11, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (11, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (12, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (12, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (13, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (13, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (14, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (14, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (15, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (15, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (16, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (16, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (17, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (17, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (18, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (18, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (19, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (19, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (20, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (20, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (21, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (21, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (22, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (22, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (23, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (23, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (24, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (24, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (25, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (25, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (26, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (26, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (27, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (27, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (28, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (28, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (29, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (29, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (30, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (30, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (31, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (31, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (33, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (33, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (34, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (34, 11);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (35, 9);

 


 

INSERT INTO materialpreset_stainingprototype (materialpreset_id, stainingprototypes_id) VALUES (35, 11);

 


 


 


 

--

 


 

-- TOC entry 2661 (class 0 OID 28977)

 


 

-- Dependencies: 214

 


 

-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO organization (id, intern, name, note, version, contact_id) VALUES (2, false, 'Klinik für Augenheilkunde Klinische Forschung', NULL, 0, 39);

 


 

INSERT INTO organization (id, intern, name, note, version, contact_id) VALUES (1, false, 'Klinik für Augenheilkunde', NULL, 2, 32);

 


 


 


 

--

 


 

-- TOC entry 2662 (class 0 OID 28985)

 


 

-- Dependencies: 215

 


 

-- Data for Name: organization_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO organization_aud (id, rev, revtype, intern, name, note, contact_id) VALUES (1, 52, 0, false, 'Klinik für Augenheilkunde', NULL, 32);

 


 

INSERT INTO organization_aud (id, rev, revtype, intern, name, note, contact_id) VALUES (2, 55, 0, false, 'Klinik für Augenheilkunde Klinische Forschung', NULL, 39);

 


 

INSERT INTO organization_aud (id, rev, revtype, intern, name, note, contact_id) VALUES (1, 62, 1, false, 'Klinik für Augenheilkunde', NULL, 32);

 


 


 


 

--

 


 

-- TOC entry 2663 (class 0 OID 28993)

 


 

-- Dependencies: 216

 


 

-- Data for Name: organization_person; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2664 (class 0 OID 28996)

 


 

-- Dependencies: 217

 


 

-- Data for Name: organization_person_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 

 


 


 


 

--

 


 

-- TOC entry 2738 (class 0 OID 0)

 


 

-- Dependencies: 259

 


 

-- Name: organization_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('organization_sequence', 2, true);

 


 


 


 

--

 


 

-- TOC entry 2666 (class 0 OID 29009)

 


 

-- Dependencies: 219

 


 

-- Data for Name: patient_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2667 (class 0 OID 29017)

 


 

-- Dependencies: 220

 


 

-- Data for Name: patient_pdfcontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2668 (class 0 OID 29020)

 


 

-- Dependencies: 221

 


 

-- Data for Name: patient_pdfcontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2739 (class 0 OID 0)

 


 

-- Dependencies: 260

 


 

-- Name: patient_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('patient_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2670 (class 0 OID 29033)

 


 

-- Dependencies: 223

 


 

-- Data for Name: pdfcontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2740 (class 0 OID 0)

 


 

-- Dependencies: 261

 


 

-- Name: pdfs_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('pdfs_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2672 (class 0 OID 29049)

 


 

-- Dependencies: 225

 


 

-- Data for Name: person_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (1, 53, 1, false, NULL, NULL, 'Andreas', 1, NULL, 'Glatz', NULL, 'Dr.', 1);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (32, 54, 0, false, NULL, NULL, 'Kristina', 1, NULL, 'Schölles', NULL, 'Dr.', 33);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (38, 56, 0, false, NULL, NULL, 'Susanne', 1, NULL, 'Ißleib', NULL, '', 40);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (38, 57, 1, false, NULL, NULL, 'Susanne', 1, NULL, 'Ißleib', NULL, '', 40);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (4, 60, 1, false, NULL, NULL, 'Thomas', 0, NULL, 'Reinhard', NULL, 'Prof.Dr.', 4);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (5, 62, 1, false, NULL, NULL, 'Hans', 0, NULL, 'Mittelviefhaus', NULL, 'Prof.Dr.', 5);

 


 

INSERT INTO person_aud (id, rev, revtype, archived, birthname, birthday, firstname, gender, language, lastname, note, title, contact_id) VALUES (6, 64, 1, false, NULL, NULL, 'Claudia', 1, NULL, 'Auw-Hädrich', NULL, 'Apl.Prof.Dr.', 6);

 


 


 


 

--

 


 

-- TOC entry 2673 (class 0 OID 29057)

 


 

-- Dependencies: 226

 


 

-- Data for Name: person_organization; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (1, 1);

 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (32, 1);

 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (38, 2);

 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (4, 1);

 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (5, 1);

 


 

INSERT INTO person_organization (person_id, organization_id) VALUES (6, 1);

 


 


 


 

--

 


 

-- TOC entry 2674 (class 0 OID 29060)

 


 

-- Dependencies: 227

 


 

-- Data for Name: person_organization_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (53, 1, 1, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (54, 32, 1, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (56, 38, 2, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (57, 38, 2, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (60, 4, 1, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (62, 5, 1, 0);

 


 

INSERT INTO person_organization_aud (rev, person_id, organization_id, revtype) VALUES (64, 6, 1, 0);

 


 


 


 

--

 


 

-- TOC entry 2741 (class 0 OID 0)

 


 

-- Dependencies: 262

 


 

-- Name: person_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('person_sequence', 81, true);

 


 


 


 

--

 


 

-- TOC entry 2676 (class 0 OID 29073)

 


 

-- Dependencies: 229

 


 

-- Data for Name: physician_associatedroles; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (1, 'OTHER_PHYSICIAN');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (2, 'OTHER_PHYSICIAN');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (3, 'OTHER_PHYSICIAN');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (7, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (8, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (9, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (10, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (11, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (12, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (13, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (14, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (15, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (16, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (17, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (18, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (19, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (20, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (21, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (22, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (23, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (24, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (25, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (26, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (27, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (28, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (29, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (30, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (21, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (38, 'SIGNATURE');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (32, 'SIGNATURE');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (4, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (5, 'SURGEON');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (6, 'SIGNATURE');

 


 

INSERT INTO physician_associatedroles (physician_id, associatedroles) VALUES (6, 'SURGEON');

 


 


 


 

--

 


 

-- TOC entry 2677 (class 0 OID 29076)

 


 

-- Dependencies: 230

 


 

-- Data for Name: physician_associatedroles_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (54, 32, 'SIGNATURE', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (56, 38, 'OTHER_PHYSICIAN', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (57, 38, 'SURGEON', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (58, 38, 'SIGNATURE', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (59, 32, 'SIGNATURE', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (60, 4, 'SURGEON', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (63, 5, 'SURGEON', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (64, 6, 'SIGNATURE', 0);

 


 

INSERT INTO physician_associatedroles_aud (rev, physician_id, associatedroles, revtype) VALUES (64, 6, 'SURGEON', 0);

 


 


 


 

--

 


 

-- TOC entry 2678 (class 0 OID 29081)

 


 

-- Dependencies: 231

 


 

-- Data for Name: physician_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (32, 54, 0, false, true, 'Ärztin', '1-30038747-0', 'schoelle', 32);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (38, 56, 0, false, true, 'Ärztin', '1-30024710-0', 'issleibs', 38);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (38, 57, 1, false, true, 'Ärztin', '1-30024710-0', 'issleibs', 38);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (38, 58, 1, false, true, 'Ärztin', '1-30024710-0', 'issleibs', 38);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (32, 59, 1, false, true, 'Ärztin', '1-30038747-0', 'schoelle', 32);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (4, 60, 1, false, true, 'Ärztlicher Direktor', '1-30006999-0', 'treinhar', 4);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (5, 63, 1, false, true, 'Oberarzt', '1-26604181-0', 'mvh', 5);

 


 

INSERT INTO physician_aud (id, rev, revtype, archived, clinicemployee, clinicrole, employeenumber, uid, person_id) VALUES (6, 64, 1, false, true, 'Oberärztin', '1-27304491-0', 'auw', 6);

 


 


 


 

--

 


 

-- TOC entry 2742 (class 0 OID 0)

 


 

-- Dependencies: 263

 


 

-- Name: physician_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('physician_sequence', 81, true);

 


 


 


 

--

 


 

-- TOC entry 2680 (class 0 OID 29097)

 


 

-- Dependencies: 233

 


 

-- Data for Name: sample_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2743 (class 0 OID 0)

 


 

-- Dependencies: 264

 


 

-- Name: sample_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('sample_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2682 (class 0 OID 29110)

 


 

-- Dependencies: 235

 


 

-- Data for Name: signature_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2744 (class 0 OID 0)

 


 

-- Dependencies: 265

 


 

-- Name: signature_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('signature_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2684 (class 0 OID 29123)

 


 

-- Dependencies: 237

 


 

-- Data for Name: slide_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2745 (class 0 OID 0)

 


 

-- Dependencies: 266

 


 

-- Name: slide_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('slide_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2746 (class 0 OID 0)

 


 

-- Dependencies: 267

 


 

-- Name: stainingprototype_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('stainingprototype_sequence', 22, true);

 


 


 


 

--

 


 

-- TOC entry 2687 (class 0 OID 29147)

 


 

-- Dependencies: 240

 


 

-- Data for Name: task_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2688 (class 0 OID 29155)

 


 

-- Dependencies: 241

 


 

-- Data for Name: task_favouritelist; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2689 (class 0 OID 29158)

 


 

-- Dependencies: 242

 


 

-- Data for Name: task_pdfcontainer; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2690 (class 0 OID 29161)

 


 

-- Dependencies: 243

 


 

-- Data for Name: task_pdfcontainer_aud; Type: TABLE DATA; Schema: public; Owner: postgres

 


 

--

 


 


 


 


 

--

 


 

-- TOC entry 2747 (class 0 OID 0)

 


 

-- Dependencies: 268

 


 

-- Name: task_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('task_sequence', 1, false);

 


 


 


 

--

 


 

-- TOC entry 2748 (class 0 OID 0)

 


 

-- Dependencies: 269

 


 

-- Name: user_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres

 


 

--

 


 


 

SELECT pg_catalog.setval('user_sequence', 5, true);

 


 


 


 

-- Completed on 2017-07-10 18:22:52

 


 


 

--

 


 

-- PostgreSQL database dump complete

 


 

--